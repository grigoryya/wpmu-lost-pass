=== WPMU LOST PASS ===
Contributors: grigoryya
Tags: security, password
Requires at least: 4.1
Tested up to: 4.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin WPMU LOST PASS allows you to create new admin password if you lost it.

== Description ==

Plugin WPMU LOST PASS allows you to create new admin password if you lost it.

== Installation ==

## Installation of WPMU LOST PASS is extremely easy. ##

1. Upload the `wpmu-lost-pass.php` file to the `/wp-content/mu-plugins/` directory of your WordPress installation.
2. Follow at `/wpmu-lost-pass` url directly or find link at wordpress login page.
3. Delete plugin file after use.