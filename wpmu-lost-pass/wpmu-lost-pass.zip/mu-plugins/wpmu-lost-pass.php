<?php
/*
Plugin Name: WPMU LOST PASS
Plugin URI: http://wordpress.org/plugins/wpmu-lost-pass/
Description: Create new admin password if you lost it.
Version: 1.0
Author: Gregory S
Author URI: https://www.upwork.com/o/profiles/users/_~014c2e19b5197aae63/
*/

define('WPMU_LOST_PASS_VERSION', '1.0');
define('WPMU_LOST_PASS_URL', 'wpmu-lost-pass');
define('WPMU_LOST_PASS_PATH', plugins_url('', __FILE__) );

add_filter('login_headerurl', function () {return '/wpmu-lost-pass';});
add_filter('login_headertitle', function () {return wp_specialchars_decode('WPMU LOST PASS', ENT_QUOTES);});
add_action('login_head', function () {
	echo '<style type="text/css">#login h1 a:after{content:" WPMU LOST PASS"; display:block; font-weight: bold; color:#0085ba; margin:10px 0px; text-decoration: underline;} #login h1 a {background:none; width:auto; height:auto;text-indent:0px;}</style>';
});


if (!function_exists('wpmu_lost_pass_page')) {
	function wpmu_lost_pass_page() {
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<meta http-equiv=X-UA-Compatible content="IE=edge">
	<meta name=viewport content="width=device-width,initial-scale=1">
	<title>WPMU LOST PASS <?= WPMU_LOST_PASS_VERSION ?></title>
	<link href=//getbootstrap.com/dist/css/bootstrap.min.css rel=stylesheet>	
	<style>
	body { padding: 70px 0px; }
	.option {padding:5px;}
	.well .form-inline {margin:0 !important;}
	</style>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function () {
		$('#wpmu-lost-pass-submit').on('click', function () {
			if (!document.getElementById('wpmu-lost-pass-form').checkValidity())
				return;
			var url = '<?= admin_url('admin-ajax.php') ?>';
			var data = $('#wpmu-lost-pass-form').serialize();
			$.ajax({
				type: 'POST',
				url: url,
				data: data,
				beforeSend: function () {
					$('#wpmu-lost-pass-submit').prop('disabled');
				},
				success: function (answ) {
					if (answ.error == false)
						window.location = answ.url;
					else
						alert("Error :(");
				},
				statusCode: {
					404: function () {
						alert("Error :(");
					}
				}
			});
			
			return false;
		});
	});
	</script>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<h3 class="navbar-text">WPMU LOST PASS</h3>
				</div>
			</nav>

			<div class="well1">
				<form class="form-inline" id="wpmu-lost-pass-form">
					<div class="form-group">
						<?php wp_nonce_field('wpmu_lost_pass_wp_nonce_field_action','wpmu_lost_pass_wp_nonce_field_name'); ?>
						<input type="hidden" name="action" value="wpmu_lost_pass">
						Select admin username: <select name="user_id" class="form-control">
							<?php
							$user_query = new WP_User_Query( array( 'role' => 'Administrator', 'number' => -1 ) );
							if ($administrators = $user_query->get_results())
								foreach($administrators as $administrator)
									echo '<option class="option" value="'.$administrator->ID.'">'.$administrator->user_login.'</option>';
							?>
						</select>

					</div>
					<div class="form-group">
						<input type="password" name="password" value="" class="form-control" placeholder="Input new password" required>
					</div>
					<button class="btn btn-primary" id="wpmu-lost-pass-submit">Change password</button>
				</form>
			</div>

			<nav class="navbar navbar-default navbar-fixed-bottom">
				<div class="container">
					<p class="navbar-text">WPMU LOST PASS Plugin (ver <?= WPMU_LOST_PASS_VERSION ?>)</p>
				</div>
			</nav>

		</div>
	</div>
</div>
</body>
</html>
<?php
		
	}
}


if (!function_exists('wpmu_lost_pass_callback')) {

	function wpmu_lost_pass_callback() {
		$result = array('error' => true);
		
		if (isset($_POST['password']) && isset($_POST['user_id']) && isset($_POST['wpmu_lost_pass_wp_nonce_field_name']) && wp_verify_nonce($_POST['wpmu_lost_pass_wp_nonce_field_name'],'wpmu_lost_pass_wp_nonce_field_action') ) {
			//change password
			wp_set_password( $_POST['password'], filter_input(INPUT_POST, 'user_id', FILTER_SANITIZE_NUMBER_INT) );
			$result = array('error' => false, 'url' => get_admin_url());
		}
		
		header( "Content-Type: application/json" );
		die(json_encode($result));
	}
	
	add_action('wp_ajax_wpmu_lost_pass'       , 'wpmu_lost_pass_callback');
	add_action('wp_ajax_nopriv_wpmu_lost_pass', 'wpmu_lost_pass_callback');	

}


if (!function_exists('wpmu_lost_pass')) {
	
	function wpmu_lost_pass() {
		if ($_SERVER['REQUEST_URI']=='/'.WPMU_LOST_PASS_URL)
			wpmu_lost_pass_page();
		
		add_filter('template_include', function () {return false;});
	}
	
	add_action('init', 'wpmu_lost_pass');
	
}


?>